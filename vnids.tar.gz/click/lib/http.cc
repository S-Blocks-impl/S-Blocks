#include <click/config.h>
#include <click/logger.h>

#include <clicknet/http.h>

#define _EXPECT(chr) \
    if(chr != *data) { return end; }

#define _CHECK(data) \
    if(data >= end) { return end; }


#define _IGNORE_SP() for(; ' '==*data; data++)

#define _BUF_SIZE 256


static inline const unsigned char* _match_string(const unsigned char* begin,
        const unsigned char* limit,
        const unsigned char* pattern,
        size_t n)
{
    if(begin + n >= limit) return NULL;
    if(0 == strncmp((const char*)pattern, (const char*)begin, n)) 
        return begin + n;
    return NULL;
}

static inline const unsigned char* _http_parse_version(const unsigned char* data,
        const unsigned char* end)
{
    // HTTP-Version SP
    static const unsigned char http_header_1_1[] = "HTTP/1.1";

    if(NULL == (data = _match_string(data, end, http_header_1_1, sizeof(http_header_1_1) - 1)))
    {
        // LOG_ERROR("HTTP-Version not matched");
        return end;
    }
    return data;
}


/** @brief Status-Line
 */
const unsigned char* _http_parse_status_line(const unsigned char* data,
        const unsigned char* end)
{
    data = _http_parse_version(data, end);
    _CHECK(data)
    // SP Status-Code SP
    data += 5;
    _CHECK(data)
    // Reason-Phrase CRLF
    for(; data<end && '\r'!=*data; data++);
    _CHECK(++data)  // '\n'
    _EXPECT(10)
    return data;
}


const unsigned char* _http_parse_method(const unsigned char* data,
        const unsigned char* end)
{
    _CHECK(data)
    static const char* method_get = "GET ";
    static const char* method_post = "POST ";
    if(strncmp(method_get, (const char*)data, 4) == 0) return data + 4;
    if(strncmp(method_post, (const char*)data, 5) == 0) return data + 5;
    return end;
}

/** @brief Request-Line <br/>
 * Request-Line   = Method SP Request-URI SP HTTP-Version CRLF
 */
const unsigned char* _http_parse_request_line(const unsigned char* data,
        const unsigned char* end)
{
    data = _http_parse_method(data, end);   // Method SP
    _CHECK(data)
    for(; data<end && ' '!=*data; data++) ; // Request-URI
    data++; // SP
    _CHECK(data)
    data = _http_parse_version(data, end);  // HTTP-Version
    ++data; // '\n'
    _CHECK(data)
    _EXPECT(10)
    return data;
}


/** @brief header
 */
const unsigned char* _http_parse_header(const unsigned char* data,
        const unsigned char* end,
        HttpHeaders *headers)
{
    const unsigned char* name_start = data;
    const unsigned char* value_start = NULL;
    for(; data<end && ':'!=*data; data++) ;
    String name = String(name_start, data-name_start);

    LOG_DEBUG("name %s", name.c_str());
    _EXPECT(':')

    _CHECK(++data)
    _IGNORE_SP();

    for(value_start=data; data<end && '\r'!=*data; data++) ;
    _CHECK(data)
    String value = String(value_start, data-value_start);
    LOG_DEBUG("value %s", value.c_str());
    _CHECK(data)
    _CHECK(++data) // '\n'

    _EXPECT(10)

    headers->insert(name, value);

    return data;
}

int http_parse(const unsigned char* data,
        const unsigned char* end,
        HttpHeaders *headers)
{
    if(end - data <= 10)
    {
        // LOG_ERROR("invalid http data");
        return 1;
    }
    if('H' == *data && 'T' == *(data+1))
    {
        data = _http_parse_status_line(data, end);
    }
    else
    {
        data = _http_parse_request_line(data, end);
    }
    if(data >= end) return -1;
    LOG_DEBUG("_http_parse_status_line/_http_parse_request_line done");

    data++;
    // message-header CRLF
    for(; data<end && '\r'!=*data; data++)
    {
        data = _http_parse_header(data, end, headers);
    }
    if(data >= end)
    {
        LOG_DEBUG("no http body");
        return 0;
    }

    // ++data; // '\n'
    // message-body @todo
    return 0;
}
