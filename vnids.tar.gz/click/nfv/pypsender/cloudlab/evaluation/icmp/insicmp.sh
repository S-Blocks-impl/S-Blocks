#!/bin/bash

python pymainsender.py file rule_icmp.cfg 1

