#!/bin/bash

ovs-ofctl mod-table ovs-lan ALL controller -O OpenFlow13

