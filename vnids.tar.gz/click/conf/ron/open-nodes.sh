xterm -title mediaone-ma -g 80x5+0+0 -e ssh -l ron mediaone-ma.ron &
xterm -title utah -g 80x5+0+90 -e ssh -l ron utah.ron &
#xterm -title sightpath -g 80x5+0+180 -e ssh -l ron sightpath.ron &
xterm -title ccicom -g 80x5+0+270 -e ssh -l ron ccicom.ron &
xterm -title cornell -g 80x5+0+360 -e ssh -l ron cornell.ron &
xterm -title msanders -g 80x5+0+450 -e ssh -l ron msanders.ron &
xterm -title aros -g 80x5+0+540 -e ssh -l ron aros.ron &
xterm -title nyu -g 80x5+0+630 -e ssh -l ron nyu.ron &

xterm -title mit -g 80x5+505+0 -e ssh -l ron mit.ron &
#xterm -title nl -g 80x5+505+90 -e ssh -l ron nl.ron &
xterm -title cmu -g 80x5+505+180 -e ssh -l ron cmu.ron &
#xterm -title lulea -g 80x5+505+270 -e ssh -l ron lulea.ron &
#xterm -title stoller -g 80x5+505+360 -e ssh -l ron stoller.ron &
xterm -title mazu1 -g 80x5+505+450 -e ssh -l ron mazu1.ron &
xterm -title pdi -g 80x5+505+540 -e ssh -l ron pdi.ron &
#xterm -title nc -g 80x5+505+630 -e ssh -l ron nc.ron &
xterm -title kr -g 80x5+505+720 -e ssh -l ron kr.ron &
