var searchData=
[
  ['anno_5fsize',['anno_size',['../class_packet.html#a9da06ca41f8744c66f57db271302fbbba37ffbe2ed8e612868890511c356dc4f7',1,'Packet']]]
];
