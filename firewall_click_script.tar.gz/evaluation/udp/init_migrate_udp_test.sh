#!/bin/bash

#------------------------------- ------------------------------------------------
#   This script launches firewall instance. 
#   The given name must exist. 
#   That is to say, instance_name.xen, instance_name.click and instance_name.flows
#   must exist at current directory.
#------------------------------- ------------------------------------------------

if [[ -z $1 ]]; then
    echo "Usage: "$0" <instance name> <number of dummy rules>"
    echo "E.g., "$0" state_firewall_01 1000 "
    exit 1;
fi

xl create ./"$1.xen" 
sleep 0.2
cosmos start $1 "$1.click"
sleep 0.15
# get traffic port. 
port=$(ovs-ofctl show ovs-lan|grep `xl list|grep $1 |awk '{print $2}'`"\.0" |cut -d '(' -f1| tr -d ' ')
# update ovs. 
#sed -i 's/,strip_vlan,output:.*/,strip_vlan,output:'"$port"'/' "$1.flows"
#ovs-ofctl add-flows ovs-lan "$1.flows"
sed -i 's/,strip_vlan,output:.*/,strip_vlan,output:'"$port"'/' "$1_$2.flows"
ovs-ofctl add-flows ovs-lan "$1_$2.flows"
if [[ $? -ne 0 ]]; then 
    echo $?
    exit 1
fi 

cd /local/work/clickos-setup/clickos/nfv/pypsender/cloudlab/ 
# install udp rules and activate.
./insudp.sh $2
./activation.sh 1

xl console $1 

