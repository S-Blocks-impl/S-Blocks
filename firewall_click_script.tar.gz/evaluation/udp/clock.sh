#!/bin/bash


if [[ -z $6 ]]; then 
    echo "Usage: $0 ... "
    exit 1
fi

ssh hongdal@10.130.127.1 "cd /local/work/client-server/evaluation/udp/; sudo ./interface.sh 10" &
echo "Back!"
sleep 4
./run_migrate_udp_test.sh $1 $2 $3 $4 $5 $6

