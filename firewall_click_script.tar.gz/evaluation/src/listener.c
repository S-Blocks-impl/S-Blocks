/*************************************************************************
> File Name: listener.c
> Author:   Hongda Li  
> Created Time: Mon 13 Jul 2015 02:59:35 PM MDT

    Compile :   gcc listen.c -lpcap [-o output]
    
*************************************************************************/
#include <pcap.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netinet/if_ether.h> 
#include <sys/types.h>
#include <unistd.h>

/* callback function that is passed to pcap_loop(..) and called each time 
 * a packet is recieved                                                    */
void my_callback(u_char *dst_mac,const struct pcap_pkthdr* pkthdr,const u_char*
        packet)
{
    int i = 0;
    // check ether address
    uint8_t* p = (uint8_t*)packet;
    if ( 0 != memcmp(dst_mac, p+6, 6) ) {
        return;
    }
    // check ether_type
    uint16_t ether_type = ntohs(*(p+12));
    if ( 0x0800 != ether_type ) {
        return;
    }
    // check ip protocol.
    uint8_t* ip = p+14;
    uint8_t ip_p = *(ip+9);
    if ( 0xfc != ip_p ) {
        return;
    }
    // It's from destination firewall.
    exit(0);
}

static inline uint8_t 
char2digit(uint8_t c) {
    switch (c) {
        case 'a' : case 'A' : return 0x0a;
        case 'b' : case 'B' : return 0x0b;
        case 'c' : case 'C' : return 0x0c;
        case 'd' : case 'D' : return 0x0d;
        case 'e' : case 'E' : return 0x0e;
        case 'f' : case 'F' : return 0x0f;
        default: return c - '0';
    }
}

int main(int argc,char **argv)
{ 
    int i;
    char *dev; 
    uint8_t *dst;
    char errbuf[PCAP_ERRBUF_SIZE];
    char dst_mac[6];
    pcap_t* descr;
    FILE *fp = NULL;
    
    /* At least two arguments. User should indicates the interface. */
    if( argc < 3 ) { 
        fprintf(stderr,"Usage: %s <interface> <dst_mac>\n",argv[0]);
        fflush(stderr); 
        return 1;
    }
    /* User should tell the name of the device */
    dev = argv[1];
    /* open device for reading */
    /* dev      :   listen on 'dev' 
     * BUFSIZ   :   maximun number of bytes to be captrued by pcap.     
     * 0        :   not in promisc mode, only listening on packets to this host. 
     * -1       :   no-zero means waitting a time before time out (in millionseconds). 
     * errbuf   :   error message if error occurs. 
     ***/
    descr = pcap_open_live(dev,BUFSIZ,0,-1,errbuf);
    if ( descr == NULL ) { 
        printf("pcap_open_live(): %s\n",errbuf); 
        exit(1); 
    }

    dst = argv[2];
    for ( i = 0; i < 6; i++ ) {
        dst_mac[i] = (char2digit(dst[i*3]) << 4) + char2digit(dst[i*3+1]);
    }
    
    fp = fopen("listen_pid.txt", "wb+");
    fprintf(fp, "%u\n", getpid());
    fclose(fp);
    
    /* int pcap_loop(pcap_t *p, int cnt, pcap_handler callback, u_char *user)*/
    /* descr        :   device to listen to. 
     * -1           :   -1 means listen forever untill error occurs.
     * my_callback  :   function that will be called when packet is received.
     * NULL         :   point to user data, passing to my_callback function. 
     * */
    pcap_loop(descr, -1, my_callback, dst_mac);
    
    /* Exit successfully. */
    return 1;
}


