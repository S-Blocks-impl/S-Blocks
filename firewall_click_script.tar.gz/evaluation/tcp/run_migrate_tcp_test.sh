#!/bin/bash
if [[ -z $6 ]]; then 
    echo "Usage: $0 <old_instance> <new_instance> <#dummy firewall rules to move> <#real firewall rules to move> <#dummy flows to update> <#real flows to update>"
    echo "E.g., $0 state_firewall_01 state_firewall_02 400 2 100 2"
    exit 1
fi 

cd /local/work/clickos-scripts/exps/examples/stateful_firewall/evaluation/bin/
# setup a deamon to listen from VNF.
./listener ovs-lan 00:00:00:00:02:02 & 

# start a new firewall instance. (instance B)
./launch_state_firewall.sh $2
sleep 0.2 

cd /local/work/clickos-setup/clickos/nfv/pypsender/cloudlab/evaluation/exec/
# move tcp
#./movetcp.sh $3 
./movetcp.sh $3 $4

cd /local/work/clickos-scripts/exps/examples/stateful_firewall/evaluation/bin/
# start pacer. 
./pypacer.py 00:00:00:00:00:01 10.10.10.10 0 10000 0 & 


echo "./update_step_1.sh ... "
# first flow update 
./update_step_1.sh $1 $2 $5 $6

# listen to the response from destination.
pid=$(cat /local/work/clickos-scripts/exps/examples/stateful_firewall/evaluation/bin/listen_pid.txt)
while [[ -e "/proc/$pid" ]]; do 
    sleep 0.001
    pid=$(cat /local/work/clickos-scripts/exps/examples/stateful_firewall/evaluation/bin/listen_pid.txt)
done

echo "./update_step_2.sh ..."
./update_step_2.sh $2 $5 $6

#xl console $2

