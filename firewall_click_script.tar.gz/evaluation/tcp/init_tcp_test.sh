#!/bin/bash

#------------------------------- ------------------------------------------------
#   This script launches firewall instance. 
#   The given name must exist. 
#   That is to say, instance_name.xen, instance_name.click and instance_name.flows
#   must exist at current directory.
#------------------------------- ------------------------------------------------

if [[ -z $4 ]]; then
    echo "Usage: "$0" <instance name> <instance-id> <number of dummy firewall rules> <number of real firewall rules> "
    echo "E.g., "$0" state_firewall_01 1 500 2"
    exit 1;
fi

xl create ../etc/"$1.xen" 
sleep 0.2
cosmos start $1 ../etc/"$1.click"
sleep 0.2
# get traffic port. 
port=$(ovs-ofctl show ovs-lan|grep `xl list|grep $1 |awk '{print $2}'`"\.0" |cut -d '(' -f1| tr -d ' ')
# update ovs. 
sed -i 's/,output:.*/,output:'"$port"'/' "../etc/$1.flows"
ovs-ofctl add-flows ovs-lan "../etc/$1.flows"
if [[ $? -ne 0 ]]; then 
    echo $?
    exit 1
fi 

cd /local/work/clickos-setup/clickos/nfv/pypsender/cloudlab/evaluation/exec/
# install TCP rules. and activate.
./instcp.sh $2 $3 $4

./activation.sh $2

xl console $1 

