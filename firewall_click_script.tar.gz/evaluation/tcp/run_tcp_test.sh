#!/bin/bash
if [[ -z $2 ]]; then 
    echo "Usage: $0 <old_instance> <new_instance>"
    echo "E.g., $0 state_firewall_01 state_firewall_02"
    exit 1
fi 
# start a new firewall instance. (instance B)
./launch_state_firewall.sh $2
sleep 0.2 

cd /local/work/clickos-setup/clickos/nfv/pypsender/cloudlab 
# move_icmp 
./movetcp.sh

# start pacer. 
#./pypacer.py 00:00:00:00:00:01 10.10.10.10 0 10000 0 &

cd /local/work/scripts/exps/examples/stateful_firewall/
# update_step_1.sh 
./update_step_1.sh $1 $2
# sleep 0.2 
sleep 0.2
# update_step_2.sh
./update_step_2.sh $2

xl console $2

